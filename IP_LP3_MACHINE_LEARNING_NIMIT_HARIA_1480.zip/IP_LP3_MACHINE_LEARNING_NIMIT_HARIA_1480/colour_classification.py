# importing the libraries
from keras.preprocessing import image
from keras.preprocessing.image import ImageDataGenerator
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Conv2D, MaxPooling2D, Flatten
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from PIL import Image
# initialising the CNN
classifier = Sequential()

#1 - Convolution
classifier.add(Conv2D(32, 3, input_shape=(64, 64, 3), activation='relu'))

# 2 - Max Pooling
classifier.add(MaxPooling2D(pool_size=(2, 2)))

# 3-Flattening
classifier.add(Flatten())

classifier.add(Dense(units=128, activation='relu'))
classifier.add(Dense(units=3, activation='softmax'))

classifier.compile(
    optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])


train_datagen = ImageDataGenerator(
    rescale=1./255,
    shear_range=0.2,
    zoom_range=0.2,
    horizontal_flip=True)
test_datagen = ImageDataGenerator(rescale=1./255)
training_set = train_datagen.flow_from_directory('D:/Colours/Data/Train',
                                                 target_size=(64, 64),
                                                 batch_size=32,
                                                 class_mode='categorical')
test_set = test_datagen.flow_from_directory('D:/Colours/Data/Test',
                                            target_size=(64, 64),
                                            batch_size=32,
                                            class_mode='categorical')
classifier.fit_generator(training_set,
                         steps_per_epoch=150,
                         epochs=25,
                         validation_data=test_set,
                         validation_steps=62)

# After training the model, run only the followng code in Spyder or Jupyter:

path = input("Give the whole path of the Image that you want to test: ")
img_width, img_height = 64, 64
img = image.load_img(path,
                     target_size=(img_width, img_height))
img.show()
img = image.img_to_array(img)
img = np.expand_dims(img, axis=0)

result = classifier.predict(img)[0]
i, = np.where(result == 1)
if i == [0]:
    print('BLUE')
elif i == [1]:
    print('GREEN')
else:
    print('RED')
