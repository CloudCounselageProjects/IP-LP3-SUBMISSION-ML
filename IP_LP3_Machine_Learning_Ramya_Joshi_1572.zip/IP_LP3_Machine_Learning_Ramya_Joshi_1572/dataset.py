#!/usr/bin/env python
# coding: utf-8

# In[2]:


from PIL import Image
from IPython.display import display
import numpy as np
import os.path
import random
import io


# In[3]:


#Forming numpy array of rgb values
imgs = np.empty((0,200, 200, 3)) #empty dummy array, we will append to this array all the images
for i  in range(1000):
    
        img = Image.open('data\color'+str(i)+'.jpg')
        imgs = np.append(imgs, np.array(img).reshape((1, 200,200, 3)), axis=0)
imgs


# In[4]:


#saving rgb values of first pixel of each image
np.savetxt('rgbvalues.txt',imgs[:,0,0,:])


# In[5]:


# labelling for rgb values 
r=imgs[:,0,0,0]
g=imgs[:,0,0,1]
b=imgs[:,0,0,2]
lb=[]
for i in range(len(r)):
    s={"RED":r[i],"GREEN":g[i],"BLUE":b[i]}
    m=max(s.items(),key=lambda x:x[1])
    lb.append(m[0])
np.savetxt('rgblabels.txt',lb,fmt="%s")


# In[9]:


img = Image.new('RGB', [200,200],(204,204,255) )
img.save('testimg.jpg')


# In[ ]:




