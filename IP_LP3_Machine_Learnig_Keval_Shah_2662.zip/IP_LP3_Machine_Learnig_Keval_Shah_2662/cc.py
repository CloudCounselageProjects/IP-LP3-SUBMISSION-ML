import os
from PIL import Image
# import csv
import xlsxwriter
count = 0
lst = []
data = []
for r in range(0, 255, 75):
    for g in range(0, 255, 75):
        for b in range(0, 255, 75):
            if r>b and r>g:
                img = Image.new('RGB', (28, 28), (r,g,b))
                lst.append({"Red":r, "Green":g, "Blue": b, "Color":"RED"})
                count += 1
                dir = r"C:\Users\keval\OneDrive\Desktop\cloud_counselage\images\RED"
                full_path = os.path.join(dir, str(count))
                img.save(full_path+'.png', 'JPEG')
            elif g>b and g>r:
                img = Image.new('RGB', (28, 28), (r,g,b))
                lst.append({"Red":r, "Green":g, "Blue": b, "Color":"GREEN"})
                count += 1
                dir = r"C:\Users\keval\OneDrive\Desktop\cloud_counselage\images\GREEN"
                full_path = os.path.join(dir, str(count))
                img.save(full_path+'.png', 'JPEG')
            elif b>r and b>g:
                lst.append({"Red":r, "Green":g, "Blue": b, "Color":"BLUE"})
                img = Image.new('RGB', (28, 28), (r,g,b))
                count += 1
                dir = r"C:\Users\keval\OneDrive\Desktop\cloud_counselage\images\BLUE"
                full_path = os.path.join(dir, str(count))
                img.save(full_path+'.png', 'JPEG')
            data.extend(lst)
            
print(data)
print(len(data))
print(data[0])
print(data[0]['Red'])

"""
file = open("dataset", w+, newline = "")
with file:
     write = csv.writer(file)
     write.writerow(lst )
"""

workbook = xlsxwriter.Workbook("C:\\Users\\keval\\OneDrive\\Desktop\\cloud_counselage\\images\\Color_dataset.xlsx")
worksheet = workbook.add_worksheet()
worksheet.write(0,0,'RED')
worksheet.write(0,1,'GREEN')
worksheet.write(0,2,'BLUE')
worksheet.write(0,3,'Color')
print("daffasd")
for i in range(0,len(data)):
    worksheet.write(i+1,0,data[i]['Red'])
    worksheet.write(i+1,1,data[i]['Green'])
    worksheet.write(i+1,2,data[i]['Blue'])
    worksheet.write(i+1,3,data[i]['Color'])
print("Hllhdfa")
workbook.close()


        
        