import cv2
import numpy as np
import pandas as pd
import argparse

#used to take image path from command line
ap = argparse.ArgumentParser()
ap.add_argument('-i', '--image', required=True, help="Image Path")
args = vars(ap.parse_args())
img_path = args['image']


#give input image of dimensions 500x400
#keep width of image 500 or greater
#Reading the image with opencv
img1 = cv2.imread(img_path)

clicked = False
r = g = b = xposition = yposition = 0

#Read the csv file with pandas and give names to each column
index1=["color","color_name","hex","R","G","B"]
csv1 = pd.read_csv('colors.csv', names=index1, header=None)

#calculate minimum distance from all colors and get the most matching color
def getColorIdentity(R,G,B):
    minimum = 10000
    for i in range(len(csv1)):
        distance = abs(R- int(csv1.loc[i,"R"])) + abs(G- int(csv1.loc[i,"G"]))+ abs(B- int(csv1.loc[i,"B"]))
        if(distance<=minimum):
            minimum = distance
            colorname = csv1.loc[i,"color_name"]
    return colorname

#get x,y coordinates of mouse double click
def draw(event, x,y,flags,param):
    if event == cv2.EVENT_LBUTTONDBLCLK:
        global b,g,r,xposition,yposition, clicked
        clicked = True
        xposition = x
        yposition = y
        b,g,r = img1[y,x]
        b = int(b)
        g = int(g)
        r = int(r)
       
cv2.namedWindow('image')
cv2.setMouseCallback('image',draw)

while(1):

    cv2.imshow("image",img1)
    if (clicked):
   
        cv2.rectangle(img1,(20,20), (750,60), (b,g,r), -1)

        text1 = getColorIdentity(r,g,b) + ' R='+ str(r) +  ' G='+ str(g) +  ' B='+ str(b)
      
        cv2.putText(img1, text1,(15,100),4,0.7,(255,255,255),1,cv2.LINE_AA)

        #for very light colors,display text in black
        if(r+g+b>=600):
            cv2.putText(img1, text1,(15,100),4,0.7,(0,0,0),1,cv2.LINE_AA)
            
        clicked=False

    #Break the loop when user hits 'esc' key
    if cv2.waitKey(20) & 0xFF ==27:
        break
    
cv2.destroyAllWindows()
