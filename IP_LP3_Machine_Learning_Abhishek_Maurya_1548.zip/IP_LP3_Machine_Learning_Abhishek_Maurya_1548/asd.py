import numpy as np
import tensorflow as tf
from tensorflow.keras.preprocessing import image
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Conv2D, Flatten
from tensorflow.keras.preprocessing.image import ImageDataGenerator

class myCallback(tf.keras.callbacks.Callback):
    def on_epoch_end(self,epoch,logs={}):
        if(logs.get('accuracy')>=0.99):
            print('\nReached 99.0% accuracy so cancelling training!')
            self.model.stop_training=True
callbacks = myCallback()

batch_size = 128
epochs = 10
IMG_HEIGHT = 150
IMG_WIDTH = 150
CLASS=['BLUE','GREEN','RED']

train_image_generator = ImageDataGenerator(rescale=1./255)
validation_image_generator = ImageDataGenerator(rescale=1./255) 

train_data_gen = train_image_generator.flow_from_directory(batch_size=batch_size,
                                                           directory=r'COLORS\TRAIN',
                                                           shuffle=True,
                                                           color_mode="rgb",
                                                           target_size=(IMG_HEIGHT, IMG_WIDTH),
                                                           class_mode='categorical')
print(train_data_gen.class_indices)

val_data_gen = validation_image_generator.flow_from_directory(batch_size=batch_size,
                                                              directory=r'COLORS\VALIDATION',
                                                              target_size=(IMG_HEIGHT, IMG_WIDTH),
                                                              color_mode="rgb",
                                                              shuffle=False,
                                                              class_mode='categorical')

model = tf.keras.models.Sequential([
    tf.keras.layers.Conv2D(32,(3,3),activation=tf.nn.relu, input_shape=(150, 150,3)),
    tf.keras.layers.MaxPooling2D(2,2),

    tf.keras.layers.Conv2D(64,(3,3),activation=tf.nn.relu),
    tf.keras.layers.MaxPooling2D(2,2),

    tf.keras.layers.Conv2D(64,(3,3),activation=tf.nn.relu),
    tf.keras.layers.MaxPooling2D(2,2),

    tf.keras.layers.Flatten(),
    tf.keras.layers.Dense(64,activation='relu'),
    tf.keras.layers.Dense(3, activation='softmax')         
    ])

model.compile(optimizer='adam',
              loss=tf.keras.losses.CategoricalCrossentropy(from_logits=True),
              metrics=['accuracy'])

history = model.fit_generator(
    train_data_gen,
    steps_per_epoch=16575.0// batch_size,
    epochs=epochs,
    validation_data=val_data_gen,
    validation_steps=1950// batch_size,
    callbacks=[callbacks]
)

path=r'COLORS\TEST\tes.png'
img=image.load_img(path, target_size=(150,150))
x=image.img_to_array(img)
x=np.expand_dims(x, axis=0)
images=np.vstack([x])
prediction=model.predict(images, batch_size=10)
print('\n')
print(CLASS[np.argmax(prediction)])

